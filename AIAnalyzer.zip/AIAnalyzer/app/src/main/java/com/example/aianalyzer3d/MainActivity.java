package com.example.aianalyzer3d;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.net.VpnService;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

// ====================================================================
// PHẦN 1: MAIN ACTIVITY (CONTROL CENTER)
// ====================================================================
public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private Button btnStartAI, btnSniffer, btnSettings;
    private EditText etUrl;
    private boolean isSnifferActive = false;

    // Constants
    public static final String PREFS_NAME = "AI_Ultimate_v10_Attention";
    public static final String KEY_WIDTH = "width";
    public static final String KEY_HEIGHT = "height";
    public static final String KEY_BG_COLOR = "bg_color";
    public static final String KEY_TEXT_COLOR = "text_color";
    public static final String KEY_ALPHA = "alpha";
    public static final String KEY_BG_IMAGE = "bg_image_path";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(createMainUI());
        setupWebView();
        setupButtons();
    }

    private View createMainUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(30, 30, 30, 30);
        root.setBackgroundColor(0xFF0F0F0F);

        TextView title = new TextView(this);
        title.setText("🧠 AI ULTIMATE v10.0 (ATTENTION)");
        title.setTextSize(22);
        title.setTextColor(0xFF00E676);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        etUrl = new EditText(this);
        etUrl.setHint("Nhập link nhà cái...");
        etUrl.setTextColor(Color.WHITE);
        etUrl.setHintTextColor(0xFF757575);
        etUrl.setText("https://www.google.com");
        root.addView(etUrl);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setWeightSum(2);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        btnSniffer = new Button(this);
        btnSniffer.setText("🔌 SNIFFER: OFF");
        btnSniffer.setBackgroundColor(0xFF9C27B0);
        btnSniffer.setTextColor(Color.WHITE);
        btnSniffer.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btnRow.addView(btnSniffer);

        btnSettings = new Button(this);
        btnSettings.setText("⚙️ SETTINGS");
        btnSettings.setBackgroundColor(0xFF455A64);
        btnSettings.setTextColor(Color.WHITE);
        btnSettings.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btnRow.addView(btnSettings);

        root.addView(btnRow);

        btnStartAI = new Button(this);
        btnStartAI.setText("🚀 LAUNCH AI SYSTEM");
        btnStartAI.setBackgroundColor(0xFFFF1744);
        btnStartAI.setTextColor(Color.WHITE);
        btnStartAI.setTextSize(18);
        root.addView(btnStartAI);

        webView = new WebView(this);
        webView.setVisibility(View.GONE);
        root.addView(webView);

        return root;
    }

    private void setupButtons() {
        btnSniffer.setOnClickListener(v -> {
            if (!isSnifferActive) startVpnService(); else stopVpnService();
        });

        btnSettings.setOnClickListener(v -> showSettingsDialog());

        btnStartAI.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION), 123);
            } else {
                startService(new Intent(this, FloatingAIService.class));
                Toast.makeText(this, "Hệ thống Attention AI đã kích hoạt", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("⚙️ Cài Đặt Giao Diện");
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        TextView tvW = new TextView(this); tvW.setText("Width: " + prefs.getInt(KEY_WIDTH, 500));
        SeekBar seekW = new SeekBar(this); seekW.setMax(800); seekW.setProgress(prefs.getInt(KEY_WIDTH, 500));
        seekW.setOnSeekBarChangeListener(new SimpleSeekBarListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvW.setText("Width: " + progress); editor.putInt(KEY_WIDTH, progress).apply();
            }
        });
        layout.addView(tvW); layout.addView(seekW);

        Button btnImg = new Button(this); btnImg.setText("🖼 Chọn Ảnh Nền");
        btnImg.setOnClickListener(v -> {
            if (checkPerm()) startActivityForResult(new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), 999);
            else requestPerm();
        });
        layout.addView(btnImg);

        builder.setView(layout);
        builder.setNegativeButton("Đóng", null);
        builder.show();
    }

    private void startVpnService() {
        Intent intent = LocalVpnService.prepare(this);
        if (intent != null) startActivityForResult(intent, 0);
        else activateVpn();
    }

    private void stopVpnService() {
        stopService(new Intent(this, LocalVpnService.class));
        isSnifferActive = false;
        btnSniffer.setText("🔌 SNIFFER: OFF");
        btnSniffer.setBackgroundColor(0xFF9C27B0);
    }

    private void activateVpn() {
        startService(new Intent(this, LocalVpnService.class));
        isSnifferActive = true;
        btnSniffer.setText("🔌 SNIFFER: ON");
        btnSniffer.setBackgroundColor(0xFF00E676);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 0) activateVpn();
            else if (requestCode == 999 && data != null) {
                String path = getRealPathFromURI(data.getData());
                if (path != null) {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putString(KEY_BG_IMAGE, path).apply();
                    Toast.makeText(this, "Đã lưu ảnh nền!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private String getRealPathFromURI(Uri uri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor c = getContentResolver().query(uri, proj, null, null, null);
        if (c == null) return null;
        c.moveToFirst();
        String path = c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));
        c.close();
        return path;
    }

    private boolean checkPerm() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        }
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPerm() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_MEDIA_IMAGES}, 101);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 101);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new JSBridge(this), "AndroidCore");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                injectScripts();
            }
        });
    }

    private void injectScripts() {
        String js = "(function() {" +
            "var Ws = window.WebSocket;" +
            "window.WebSocket = function(u, p) {" +
            "  var ws = new Ws(u, p);" +
            "  ws.addEventListener('message', function(e) { AndroidCore.onData('WS', e.data); });" +
            "  return ws;" +
            "};" +
            "})();";
        webView.evaluateJavascript(js, null);
    }

    public static void sendToService(Context ctx, String type, String data) {
        Intent i = new Intent("ACTION_AI_UPDATE");
        i.setPackage(ctx.getPackageName());
        i.putExtra("type", type);
        i.putExtra("data", data);
        ctx.sendBroadcast(i);
    }

    static class JSBridge {
        Context ctx;
        JSBridge(Context c) { ctx = c; }
        @JavascriptInterface
        public void onData(String src, String data) { sendToService(ctx, src, data); }
    }

    static abstract class SimpleSeekBarListener implements SeekBar.OnSeekBarChangeListener {
        public void onStartTrackingTouch(SeekBar seekBar) {}
        public void onStopTrackingTouch(SeekBar seekBar) {}
    }
}

// ====================================================================
// PHẦN 2: ATTENTION SYSTEM & GENETIC AI CORE
// ====================================================================
class AIUltimateCore {
    private final List<Integer> history = new ArrayList<>();
    private final MemorySystem memory;
    private final StrategyGenome genome;

    private int lastPrediction = -1;
    private int streak = 0;

    public AIUltimateCore(SharedPreferences prefs) {
        this.memory = new MemorySystem(prefs);
        this.genome = new StrategyGenome();
        genome.load(prefs);
    }

    // --- MAIN PROCESSING PIPELINE ---
    public String process(int result) {
        // 1. Update History
        history.add(result);
        if (history.size() > 1000) history.remove(0);

        // 2. Evaluate Last Prediction (Reinforcement)
        if (lastPrediction != -1) {
            if (lastPrediction == result) {
                genome.fitness += 1;
                streak = (streak > 0) ? streak + 1 : 1;
            } else {
                genome.fitness -= 1.5;
                streak = (streak < 0) ? streak - 1 : -1;
            }
        }

        // 3. Run Attention Mechanism
        AttentionResult attention = calculateAttention(result);

        // 4. Run Logic Layers
        int pMarkov = predictMarkov();
        int pBias = predictBias();
        String pattern = getPattern(4);
        int pMemory = memory.recall(pattern);

        // 5. Decision Fusion (Using Genome Weights & Attention Scores)
        double score = 0;
        double totalWeight = 0;

        // Apply Attention Weights
        double markovW = genome.genes[2] * (1.0 + attention.shortTermFocus);
        double memoryW = genome.genes[3] * (1.0 + attention.longTermFocus);

        if (pMarkov != -1) { score += pMarkov * markovW; totalWeight += markovW; }
        if (pBias != -1) { score += pBias * 0.5; totalWeight += 0.5; }
        if (pMemory != -1) { score += pMemory * memoryW * 1.5; totalWeight += memoryW * 1.5; }

        if (totalWeight == 0) return "WAIT:DATA";

        int finalDecision = (score / totalWeight) > 0.5 ? 1 : 0;

        // 6. Update Memory
        memory.record(pattern, result);

        // 7. Evolution Check
        genome.age++;
        if (streak < -3 || genome.age > 50) evolve();

        lastPrediction = finalDecision;
        
        // 8. Output Formatting
        double confidence = (Math.max(score, totalWeight - score) / totalWeight) * 100;
        confidence = confidence * (1.0 + attention.anomalyFocus * 0.2); // Boost confidence if anomaly detected
        
        String action = (confidence > 80) ? "STRIKE" : (confidence > 60) ? "ATTACK" : "SCOUT";

        return String.format(Locale.US, "PRED:%d|CONF:%.1f|ATT:S%.2f|ACT:%s", 
                finalDecision, Math.min(99.9, confidence), attention.shortTermFocus, action);
    }

    // --- ATTENTION MECHANISM (Self-Attention) ---
    private AttentionResult calculateAttention(int current) {
        AttentionResult res = new AttentionResult();
        if (history.size() < 10) return res;

        // 1. Short-term Attention (Focus on recent patterns)
        // Query: Current state, Key: History, Value: Importance
        int recentMatch = 0;
        int sz = history.size();
        int last3 = (sz >= 3) ? (history.get(sz-1) + history.get(sz-2) + history.get(sz-3)) : 0;
        
        for (int i = 0; i < sz - 3; i++) {
            int past3 = history.get(i) + history.get(i+1) + history.get(i+2);
            // Dot product similarity (simplified)
            if (past3 == last3) recentMatch++;
        }
        res.shortTermFocus = Math.min(1.0, recentMatch / 10.0); // Normalize

        // 2. Long-term Attention (Memory Salience)
        res.longTermFocus = (memory.recall(getPattern(4)) != -1) ? 0.5 : 0.0;

        // 3. Anomaly Attention (Surprise detection)
        long taiCount = history.stream().filter(i -> i == 1).count();
        double ratio = (double) taiCount / history.size();
        if (ratio > 0.7 || ratio < 0.3) res.anomalyFocus = 1.0; // High bias = Anomaly

        return res;
    }

    private static class AttentionResult {
        double shortTermFocus = 0.0;
        double longTermFocus = 0.0;
        double anomalyFocus = 0.0;
    }

    // --- HELPER METHODS ---
    private String getPattern(int len) {
        if (history.size() < len) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = history.size() - len; i < history.size(); i++) sb.append(history.get(i));
        return sb.toString();
    }

    private int predictMarkov() {
        if (history.size() < 5) return -1;
        int last = history.get(history.size() - 1);
        int t = 0, x = 0;
        for (int i = 0; i < history.size() - 1; i++) {
            if (history.get(i) == last) {
                if (history.get(i + 1) == 1) t++; else x++;
            }
        }
        return t > x ? 1 : (x > t ? 0 : -1);
    }

    private int predictBias() {
        if (history.size() < 20) return -1;
        long tai = history.stream().filter(i -> i == 1).count();
        double ratio = (double) tai / history.size();
        if (ratio > 0.65) return 0;
        if (ratio < 0.35) return 1;
        return -1;
    }

    private void evolve() {
        if (genome.fitness < 0) {
            genome.mutate(); // Mutate heavily if bad
            genome.mutate();
        } else {
            genome.mutate(); // Light mutation if good
        }
        genome.age = 0;
        streak = 0;
        genome.fitness = 0;
    }

    public void saveState() {
        memory.save();
        // Genome saved automatically in prefs if needed, or kept in memory for session
    }
}

// ====================================================================
// PHẦN 3: GENETIC STRATEGY & MEMORY
// ====================================================================
class StrategyGenome {
    public double[] genes = new double[5]; // Aggression, Caution, PatternW, MemoryW, MutRate
    public double fitness = 0;
    public int age = 0;

    public StrategyGenome() { randomize(); }

    public void randomize() {
        for (int i = 0; i < genes.length; i++) genes[i] = Math.random();
        genes[4] = 0.1; 
    }

    public void mutate() {
        double rate = genes[4];
        for (int i = 0; i < genes.length; i++) {
            if (Math.random() < rate) {
                genes[i] += (Math.random() - 0.5) * 0.2;
                genes[i] = Math.max(0, Math.min(1, genes[i]));
            }
        }
    }

    public void load(SharedPreferences p) {
        for (int i = 0; i < genes.length; i++) genes[i] = p.getFloat("gene_" + i, 0.5f);
        fitness = p.getFloat("fitness", 0);
    }

    public void save(SharedPreferences.Editor ed) {
        for (int i = 0; i < genes.length; i++) ed.putFloat("gene_" + i, (float) genes[i]);
        ed.putFloat("fitness", (float) fitness);
    }
}

class MemorySystem {
    private static final String MEM_KEY = "episodic_memory";
    private final SharedPreferences prefs;
    private final Map<String, int[]> memory = new HashMap<>();

    public MemorySystem(SharedPreferences p) { this.prefs = p; load(); }

    public void record(String pattern, int result) {
        if (pattern == null || pattern.isEmpty()) return;
        int[] stats = memory.get(pattern);
        if (stats == null) stats = new int[2];
        if (result == 1) stats[0]++; else stats[1]++;
        memory.put(pattern, stats);
    }

    public int recall(String pattern) {
        int[] stats = memory.get(pattern);
        if (stats == null) return -1;
        if (stats[0] > stats[1] * 1.2) return 1;
        if (stats[1] > stats[0] * 1.2) return 0;
        return -1;
    }

    public void save() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, int[]> e : memory.entrySet()) sb.append(e.getKey()).append(":").append(e.getValue()[0]).append(",").append(e.getValue()[1]).append(";");
        prefs.edit().putString(MEM_KEY, sb.toString()).apply();
    }

    private void load() {
        String d = prefs.getString(MEM_KEY, "");
        if (d.isEmpty()) return;
        for (String e : d.split(";")) {
            if (e.isEmpty()) continue;
            String[] p = e.split(":");
            if (p.length < 2) continue;
            String[] v = p[1].split(",");
            if (v.length < 2) continue;
            try { memory.put(p[0], new int[]{Integer.parseInt(v[0]), Integer.parseInt(v[1])}); } catch (Exception ignored) {}
        }
    }
}

// ====================================================================
// PHẦN 4: LOCAL VPN SERVICE (SNIFFER)
// ====================================================================
class LocalVpnService extends VpnService {
    private ParcelFileDescriptor vpnInterface;
    private Thread worker;
    private volatile boolean isRunning = true;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground();
        if (vpnInterface == null) {
            Builder b = new Builder();
            b.setSession("AI_VPN"); b.addAddress("10.0.0.2", 24); b.addRoute("0.0.0.0", 0);
            try { vpnInterface = b.establish(); worker = new Thread(this::runLoop); worker.start(); } catch (Exception e) { e.printStackTrace(); }
        }
        return START_STICKY;
    }

    private void runLoop() {
        ByteBuffer buffer = ByteBuffer.allocate(32767);
        FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
        while (isRunning) {
            try {
                int len = in.read(buffer.array());
                if (len > 0) {
                    byte[] data = Arrays.copyOfRange(buffer.array(), 0, len);
                    parsePacket(data);
                }
            } catch (IOException e) { break; }
        }
    }

    private void parsePacket(byte[] packet) {
        try {
            int ipHLen = (packet[0] & 0x0F) * 4;
            int proto = packet[9] & 0xFF;
            if (proto == 6 && packet.length > ipHLen + 20) { // TCP
                int tcpHLen = ((packet[ipHLen + 12] >> 4) & 0x0F) * 4;
                int payStart = ipHLen + tcpHLen;
                if (payStart < packet.length) {
                    byte[] payload = Arrays.copyOfRange(packet, payStart, packet.length);
                    String text = new String(payload, StandardCharsets.UTF_8);
                    if (text.trim().startsWith("{") && (text.contains("dice") || text.contains("result"))) {
                        sendToAI("NET_JSON", text); return;
                    }
                    for (int i = 0; i < payload.length - 3; i++) {
                        byte b1=payload[i], b2=payload[i+1], b3=payload[i+2];
                        if (b1>=1&&b1<=6 && b2>=1&&b2<=6 && b3>=1&&b3<=6) {
                            sendToAI("NET_RAW", "DICE_BYTE:" + b1 + "," + b2 + "," + b3); return;
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private void sendToAI(String type, String data) { Intent i = new Intent("ACTION_AI_UPDATE"); i.setPackage(getPackageName()); i.putExtra("type", type); i.putExtra("data", data); sendBroadcast(i); }
    private void startForeground() {
        String id = "vpn_ch"; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(id, "VPN", NotificationManager.IMPORTANCE_DEFAULT));
        startForeground(1, new NotificationCompat.Builder(this, id).setContentTitle("AI Sniffer Active").setSmallIcon(android.R.drawable.ic_menu_search).build());
    }
    @Override public void onDestroy() { super.onDestroy(); isRunning = false; try { if (vpnInterface != null) vpnInterface.close(); } catch (Exception e) {} }
    @Override public IBinder onBind(Intent intent) { return null; }
}

// ====================================================================
// PHẦN 5: FLOATING AI SERVICE (UI)
// ====================================================================
class FloatingAIService extends Service {
    private WindowManager wm;
    private FrameLayout root;
    private TextView txtStatus;
    private GLSurfaceView glView;
    private Renderer renderer;
    private AIUltimateCore core;
    private SharedPreferences prefs;
    private Handler uiHandler;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            String type = intent.getStringExtra("type");
            String data = intent.getStringExtra("data");
            if (type == null) return;
            // Multi-Modal Perception: Prioritize Network over DOM
            if (type.startsWith("NET_") || type.equals("WS")) processInput(data);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
        core = new AIUltimateCore(prefs);
        uiHandler = new Handler(Looper.getMainLooper());
        createWindow();
        registerReceiver(receiver, new IntentFilter("ACTION_AI_UPDATE"));
    }

    private void processInput(String data) {
        try {
            JSONArray arr = null;
            if (data.startsWith("{")) arr = new JSONObject(data).getJSONArray("dice");
            else if (data.startsWith("[")) arr = new JSONArray(data);
            else if (data.startsWith("DICE_BYTE:")) {
                String[] p = data.replace("DICE_BYTE:", "").split(",");
                arr = new JSONArray("[" + p[0] + "," + p[1] + "," + p[2] + "]");
            }
            else { Matcher m = Pattern.compile("\\[(\\d+),(\\d+),(\\d+)\\]").matcher(data); if(m.find()) arr = new JSONArray("["+m.group(1)+","+m.group(2)+","+m.group(3)+"]"); }

            if (arr != null) {
                int sum = arr.getInt(0) + arr.getInt(1) + arr.getInt(2);
                int result = (sum >= 11) ? 1 : 0;
                String analysis = core.process(result);
                updateUI(analysis);
                if (renderer != null) glView.queueEvent(() -> renderer.triggerEffect(result));
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void updateUI(String text) { uiHandler.post(() -> txtStatus.setText(text)); }

    @SuppressLint("ClickableViewAccessibility")
    private void createWindow() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        root = new FrameLayout(this);
        SharedPreferences p = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
        int w = p.getInt(MainActivity.KEY_WIDTH, 500);
        int h = p.getInt(MainActivity.KEY_HEIGHT, 500);
        int color = p.getInt(MainActivity.KEY_BG_COLOR, Color.BLACK);
        float alpha = p.getFloat(MainActivity.KEY_ALPHA, 0.9f);
        String imgPath = p.getString(MainActivity.KEY_BG_IMAGE, null);

        root.setBackgroundColor(color); root.setAlpha(alpha);
        if (imgPath != null) { try { ImageView bg = new ImageView(this); bg.setImageBitmap(BitmapFactory.decodeFile(imgPath)); bg.setScaleType(ImageView.ScaleType.CENTER_CROP); root.addView(bg, new FrameLayout.LayoutParams(-1, -1)); } catch (Exception ignored) {} }

        LinearLayout header = new LinearLayout(this); header.setBackgroundColor(0xCC000000); header.setPadding(10, 5, 10, 5);
        TextView title = new TextView(this); title.setText("👁️ AI v10.0"); title.setTextColor(Color.WHITE); title.setTextSize(16); title.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageButton btnClose = new ImageButton(this); btnClose.setImageResource(android.R.drawable.ic_menu_close_clear_cancel); btnClose.setBackgroundColor(Color.TRANSPARENT); btnClose.setOnClickListener(v -> stopSelf());
        header.addView(btnClose);
        root.addView(header);

        glView = new GLSurfaceView(this); glView.setEGLContextClientVersion(2); glView.setEGLConfigChooser(8,8,8,8,16,0);
        renderer = new Renderer(); glView.setRenderer(renderer); glView.getHolder().setFormat(PixelFormat.TRANSLUCENT); glView.setZOrderOnTop(true);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(300, 300); glp.gravity = Gravity.CENTER;
        root.addView(glView, glp);

        txtStatus = new TextView(this); txtStatus.setTextColor(Color.WHITE); txtStatus.setTextSize(12); txtStatus.setGravity(Gravity.CENTER); txtStatus.setText("Initializing Attention...");
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, -2); tp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        root.addView(txtStatus, tp);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(w, h, 
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE, 
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        wm.addView(root, params);

        header.setOnTouchListener(new View.OnTouchListener() {
            int initX, initY; float tX, tY;
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: initX = params.x; initY = params.y; tX = e.getRawX(); tY = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE: params.x = initX + (int)(e.getRawX() - tX); params.y = initY + (int)(e.getRawY() - tY); wm.updateViewLayout(root, params); return true;
                }
                return false;
            }
        });
    }

    @Override public void onDestroy() { super.onDestroy(); if (receiver != null) unregisterReceiver(receiver); if (wm != null && root != null) wm.removeView(root); core.saveState(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}

// ====================================================================
// PHẦN 6: WORLD SIMULATION (OPENGL ES)
// ====================================================================
class Renderer implements GLSurfaceView.Renderer {
    private final List<Cube> entities = new ArrayList<>();
    private final Random random = new Random();
    private long eventTime = 0;

    public Renderer() { for (int i = 0; i < 20; i++) entities.add(new Cube(random.nextFloat() * 6 - 3, random.nextFloat() * 6 - 3, random.nextFloat() * 6 - 3)); }

    @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) { gl.glClearColor(0f, 0f, 0f, 0f); gl.glEnable(GL10.GL_DEPTH_TEST); gl.glEnable(GL10.GL_BLEND); gl.glBlendFunc(GL10.GL_SRC_ALPHA, GL10.GL_ONE_MINUS_SRC_ALPHA); }
    @Override public void onSurfaceChanged(GL10 gl, int w, int h) { gl.glViewport(0, 0, w, h); gl.glMatrixMode(GL10.GL_PROJECTION); gl.glLoadIdentity(); float ratio = (float) w / h; android.opengl.GLU.gluPerspective(gl, 45, ratio, 1, 100); gl.glMatrixMode(GL10.GL_MODELVIEW); }

    @Override
    public void onDrawFrame(GL10 gl) {
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
        gl.glLoadIdentity();
        android.opengl.GLU.gluLookAt(gl, 0f, 0f, 10f, 0f, 0f, 0f, 0f, 1f, 0f);
        float time = System.currentTimeMillis() / 1000f;

        for (Cube c : entities) {
            gl.glPushMatrix();
            c.x += Math.sin(time + c.seed) * 0.01f; c.y += Math.cos(time + c.seed) * 0.01f; c.rot += c.speed;
            gl.glTranslatef(c.x, c.y, c.z);
            gl.glRotatef(c.rot, 1f, 1f, 0f);
            if (System.currentTimeMillis() - eventTime < 500) gl.glColor4f(1f, 1f, 1f, 1f); else gl.glColor4f(c.r, c.g, c.b, 0.8f);
            c.draw(gl);
            gl.glPopMatrix();
        }
    }

    public void triggerEffect(int result) { eventTime = System.currentTimeMillis(); for (Cube c : entities) c.speed = random.nextFloat() * 10; }
}

class Cube {
    float x, y, z, rot = 0, speed = 1, seed;
    float r, g, b;
    private FloatBuffer vb;
    private ByteBuffer ib;

    public Cube(float x, float y, float z) {
        this.x = x; this.y = y; this.z = z; this.seed = (float) Math.random() * 100;
        this.r = (float) Math.random(); this.g = (float) Math.random(); this.b = (float) Math.random();
        float[] v = { -0.2f, -0.2f, 0.2f, 0.2f, -0.2f, 0.2f, 0.2f, 0.2f, 0.2f, -0.2f, 0.2f, 0.2f, -0.2f, -0.2f, -0.2f, -0.2f, 0.2f, -0.2f, 0.2f, 0.2f, -0.2f, 0.2f, -0.2f, -0.2f };
        byte[] i = { 0,1,2, 0,2,3, 4,5,6, 4,6,7, 0,3,5, 0,5,4, 1,2,6, 1,6,7 };
        ByteBuffer bb = ByteBuffer.allocateDirect(v.length * 4); bb.order(ByteOrder.nativeOrder()); vb = bb.asFloatBuffer(); vb.put(v); vb.position(0);
        ib = ByteBuffer.allocateDirect(i.length); ib.put(i); ib.position(0);
    }
    public void draw(GL10 gl) { gl.glEnableClientState(GL10.GL_VERTEX_ARRAY); gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vb); gl.glDrawElements(GL10.GL_TRIANGLES, 24, GL10.GL_UNSIGNED_BYTE, ib); gl.glDisableClientState(GL10.GL_VERTEX_ARRAY); }
}
